from distutils.core import setup

setup(
    name='projectMLinCV',
    version='0.0.1',
    packages=[''],
    url='https://github.com/mariarzv/projectMLinCV',
    license='GNU',
    author='mariarv',
    author_email='maria.razzv@gmail.com',
    description='yolov5'
)
