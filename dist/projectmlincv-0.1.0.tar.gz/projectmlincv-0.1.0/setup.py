# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['projectmlincv']

package_data = \
{'': ['*']}

install_requires = \
['Pillow>=9.4.0,<10.0.0',
 'argparse>=1.4.0,<2.0.0',
 'numpy>=1.24.2,<2.0.0',
 'opencv-contrib-python>=4.7.0.72,<5.0.0.0',
 'tensorflow>=2.11.1,<3.0.0',
 'yolov5>=7.0.11,<8.0.0']

entry_points = \
{'console_scripts': ['demo = python demo.py']}

setup_kwargs = {
    'name': 'projectmlincv',
    'version': '0.1.0',
    'description': '',
    'long_description': '# projectMLinCV\nProject "Machine learning in computer vision"\n\n# Demo projects\n\n## YOLOv5 with TensorFlow Lite in C++\nhttps://github.com/iwatake2222/play_with_tflite/tree/master/pj_tflite_det_yolov5\n\n\nTested on Windows 10, in PyCharm\n\n# projectMLinCV\nusing yolov5\n\nTest image inference and video inference\n\n## Prerequisites\n\n - Needs Python to run, tested with Python 3.9\n - Needs pip to run pip install commands, to check if you have pip run `py -m pip --version`\n - If you installed Python from source, with an installer from python.org, or via Homebrew you should already have pip. If you’re on Linux and installed using your OS package manager, you may have to install pip separately, see [installing pip/setuptools/wheel with Linux Package Managers](https://packaging.python.org/en/latest/guides/installing-using-linux-tools/)\n - Needs poetry installed in order to manage environments, on Windows installation is: `(Invoke-WebRequest -Uri https://install.python-poetry.org -UseBasicParsing).Content | py -` or other versions of this command for your operating system.  \n - You can check if you have poetry installed: `poetry --version`\n\n## Installation\n\nTo install the project, follow these steps:\n\n1. Navigate to your folder and create poetry virtual environment `poetry env use python 3.9` or other Python version you have, to check your version run `python --version`\n2. Make sure you have poetry-core installed: `pip install poetry-core`\n3. To install the project directly from repository use `pip install git+https://github.com/mariarzv/projectMLinCV@assignment1`\n4. Install the required dependencies by running `pip install -r requirements.txt` in the terminal.\n5. Run `cd dist` and `pip install projectMLinCV-0.0.1-py2.py3-none-any.whl` to install the project using the wheel file. If project is already installed with the same version as the provided wheel you can use --force-reinstall to force an installation of the wheel.\n\n\n\n\n\n\n',
    'author': 'mariarzv',
    'author_email': 'maria.razzv@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
